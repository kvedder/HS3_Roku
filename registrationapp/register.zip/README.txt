The register example demonstrates how to do rendezvous style
registration.  Rendezvous registration presents the user with
a code (like Netflix, Amazon, etc.) and the user goes to the
providers web site to establish a link between the user account
and the box by using a short link code.

The example app doesn't talk to a real backend DB, like a 
production system would (you must provide that piece), but
it shows how he client side might work and a sample of the
type of XML request/response API's that would be required.

Please see the document RokuDvp-DeviceRegistrationAndLinking.pdf
for more information on this topic.  
